# Changes from AllTheMons
AllTheMons x Mega Showdown aims to make the two compatible with each other by overriding the assets of MSD and removing certain ones from ATM. Here's an overview of all changes made:

## Overridden by ATM x MSD: 
### Genomons:
Bloodmoon Ursaluna, Mewtwo, Cosmog, Cosmoem, Ultra Necrozma, Xerneas

### Kales Collection:
Deoxys (Normal, Attack, Defense, Speed forme)


## Removed from ATM x MSD 
### AllonesAdditions:
**Consistency with Megas:**  
Houndoom, Houndour

### AlphabetSoup:
**Same Models:**  
Unown (all Forms)

### Genomons:
**Better in MSD:**  
Entei, Miraidon, Ho-Oh, Lugia, Calyrex, Spectrier, Glastrier (and their fusions), Tapu Koko, Zygarde (10%, 50% & 100%)

### HiddenMons: 
**Consistency with Megas:**  
Swablu, Altaria, Shuppet, Banette  

### MissingMons:
**Same Models:**  
Rockruff, Lycanroc, Ogerpon, Rotom, Shaymin, Genesect, Marshadow, Morpeko, Meltan, Melmetal

### Hydros Reanimodel:
**Same Models:**  
Azelf, Mesprit, Uxie, Dawn Wings, Dialga, Dusk Mane, Palkia, Giratina, Lunala, Solgaleo, Necrozma

**Consistency with Megas:**
Meditite, Medicham

### OdysseyMons:
**Same Models:**  
Toxel, Toxtricity

### PigeonsPokePack:
**Consistency with Megas:**  
Snorunt, Glalie, Froslass
**Better in MSD:**  
Volcanion

### Pokemans:
**Same Models:**  
Arceus, Eternatus, Kubfu, Urshifu, Type-Null, Silvally, Kyogre, Groudon, Hoopa, Keldeo, Zekrom, Reshiram, Kyurem

**Consistency with Megas:**  
Latias, Latios, Rayquaza

**Better in MSD:**  
Eternatus, Landorus, Tornadus, Thundurus

### The Jewel Pokémon:
**Same Model:**  
Diancie, Mega Diancie