## Howdy! 
I'm easysqueeze, the creator of this pack.
I didn't make any of the incredible models or animations in this pack, all of those are added by individual contributors who spent a ton of their time to make this pack a reality.
Please note I have the full permission of all contributors of this pack to use their assets, you can find proof in the folder titled "proofs of permission"

## Discord:
ask questions there in the discord, please do not DM me questions

THE LOCATION OF EVERY POKEMON'S SPAWN CAN BE FOUND IN THE DISCORD! SIMPLY TYPE !spawn IN ANY CHANNEL

## Info doc:
https://docs.google.com/document/d/1nPZxD0zWqaCsulp_RCRTiQS5YxUrdoE6xv8rsMoWSYs


## Contributors:
Genotype (genotypexd), the creator of GenoMons  
Raspix, the creator of CobbleCats  
ASHISK, the creator of Ashimons and a contributor to Pokemans Pack  
Kale, the creator of Kale's Collection  
Bwavii, the creator of WaviMons  
RedRibbon, the creator of MissingMons  
El Pigeon, the creator of Pigeon's PokePack  
NetImmerse, the creator of The Jewel Pokemon  
IZetyXX, one of the creators of LackingMons and a contributor to Pokemans Pack  
LegenTM, the creator of HiddenMons  
Allone, the creator of Allone's Additions  
BeeZy, one of the creators of LackingMons  
Wi2tert, the creator CloudMons  
Pandalistics, a contributor to Pokemans Pack  
Tontra, the creator of Pokemans Pack  
Lazaro, a contributor to Pokemans Pack  
笑声, a contributor to Pokemans Pack  
BlazeHydroxide, the creator of Hydro's Reanimodel Pack  
YaBoiBruno, the creator of MoreMons  
Omniv, the creator of Shadow Mega Mewtwo X & Y  
Nady3, the creator of NadyMons3
Bonanca, the creator of BoniMons & MonkeyMons
Zayden, the creator of Dyeable Smeargle Fix, Deoxys Meteorite Item & Water Shuriken 
JoeSeff, the creator of Lucario Overhaul
Zalno, the creator of Fire Fits for Fire Cats 
Blue, the creator of many ATM x MSD sprites
Sanji, the creator of the Galarian Mega Slowbro assets
Caloriarc, the creator of the Virus Groudon assets
Sevonents, the creator of the Primal Dialga textures


## Other important people:
SpencyRock (spencyrock), the creator of UltiMons and the inspiration for this pack, as well as significant information contributions  
Frank The Farmer (frankthefarmer), who helped me a ton with coding JSONs and was instrumental in the creation of AllTheMons  
i love you frank <3  
Squirly (squirlyvgc), who also helped with the JSONs and spawn files  
MaYayoh and DonTomas for creating the discord bot that tells people where stuff spawns  
MaYayoh (again) and Lvnatic for answering people's questions on the discord when I couldn't/didn't want to  
Lvnatic (again) for a ton of coding contributions  
Natant (n8nt) for coding contributions  
Fire Ball for several coding contributions  